#include "VmExit.hpp"


#pragma intrinsic(__rdtsc)
#pragma intrinsic(__writemsr)
#pragma intrinsic(__readmsr)
#pragma intrinsic(__cpuidex)
#pragma intrinsic(_xsetbv)
#pragma intrinsic(__rdtscp)



namespace Vmexits
{
	
	/*
	void FlushTlbEntries(__inout _HV_CPU* currentProcessor, __inout uint32_t flushType)
	{
		currentProcessor->guestVmcb.controlArea.TlbControl.value |= flushType;
	}



	void CleanVmcb(__inout _HV_CPU* currentProcessor, __inout bool clean)
	{
		if (clean) currentProcessor->guestVmcb.controlArea.vmcbClean.value = 0x0U;
		else currentProcessor->guestVmcb.controlArea.vmcbClean.value = 0xFFFFFFFFU;
	}*/

	
	bool Cpl3(__inout _HV_CPU* currentProcessor)
	{
		return currentProcessor->guestVmcb.stateSaveArea.cpl == DPL_USER && currentProcessor->guestVmcb.controlArea.nRip < 0x7FFFFFFEFFFF;
	}



	void GeneralException(__inout _HV_CPU* currentProcessor)
	{
		_EVENTINJ exception = { 0 };

		exception.bit.type = INTERRUPT_TYPE_HARDWARE_EXCEPTION;
		exception.bit.valid = 1;
		exception.bit.errorCodeValid = 1;
		exception.bit.vector = EXCEPTION_VECTOR_GENERAL_PROTECTION_FAULT;

		currentProcessor->guestVmcb.controlArea.eventInj = exception.value;
	}



	void InvalidException(__inout _HV_CPU* currentProcessor)
	{
		_EVENTINJ exception = { 0 };

		exception.bit.type = INTERRUPT_TYPE_HARDWARE_EXCEPTION;
		exception.bit.valid = 1;
		exception.bit.errorCodeValid = 1;
		exception.bit.vector = EXCEPTION_VECTOR_UNDEFINED_OPCODE;

		currentProcessor->guestVmcb.controlArea.eventInj = exception.value;
	}



	void CpuidExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context)
	{
		_SEGMENT_ATTRIBUTES attribute = { 0 };
		auto currentLeaf = static_cast<int32_t>(context->guestRegisters->rax.GetR64());
		auto subLeaf = static_cast<int32_t>(context->guestRegisters->rcx.GetR64());

		int32_t registers[4] = { 0 };
		__cpuidex(registers, currentLeaf, subLeaf);

#ifdef HYPER_V
		
		switch (currentLeaf)
		{
		case CPUID_PROCESSOR_AND_PROCESSOR_FEATURE_IDENTIFIERS:
			registers[2] |= CPUID_FN0000_0001_ECX_HYPERVISOR_PRESENT;
			break;
		case CPUID_HV_VENDOR_AND_MAX_FUNCTIONS:
			registers[0] = CPUID_HV_MAX;
			registers[1] = 'CecI';
			registers[2] = 'elao';
			registers[3] = '   d';
			break;
		case CPUID_HV_INTERFACE:
			registers[0] = '0#vH';
			registers[1] = 0;
			registers[2] = 0;
			registers[3] = 0;
			break;
		case CPUID_UNLOAD:
			if (subLeaf == CPUID_UNLOAD)
			{
				attribute.value = currentProcessor->guestVmcb.stateSaveArea.ss.attributes.value;
				if (attribute.bit.dpl == DPL_SYSTEM)
				{
					context->exit = true;
				}
			}
			break;
		default:
			break;
		}

#endif // 

		
		context->guestRegisters->rax = registers[0];
		context->guestRegisters->rbx = registers[1];
		context->guestRegisters->rcx = registers[2];
		context->guestRegisters->rdx = registers[3];

		currentProcessor->guestVmcb.stateSaveArea.rip = currentProcessor->guestVmcb.controlArea.nRip;
	}



	void MsrExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context)
	{
		
		auto msrRegister = static_cast<uint32_t>(context->guestRegisters->rcx & MAXUINT32);
		auto writeAccess = currentProcessor->guestVmcb.controlArea.exitInfo1 != 0;
		ULARGE_INTEGER value = { 0 };

#ifdef HYPER_V
		if (!HypervMsr(msrRegister))
		{
			Vmexits::GeneralException(currentProcessor);
			goto end;
		}
#endif //!HYPER_V 

		if (OutSideMsrMap(msrRegister))
		{
			Vmexits::GeneralException(currentProcessor);
		}
		else if (writeAccess)
		{
			value.LowPart = static_cast<ULONG>(context->guestRegisters->rax & MAXUINT32);
			value.HighPart = static_cast<ULONG>(context->guestRegisters->rdx & MAXUINT32);

			if (msrRegister == MSR_EFER)
			{
				_EFER_REGISTER efer{};
				efer = value.QuadPart;
				if (!currentProcessor->guestVmcb.stateSaveArea.efer.cmpSvmeBit(efer))
				{
					Vmexits::InvalidException(currentProcessor);	
				}
				else if (!currentProcessor->guestVmcb.stateSaveArea.efer.cmpLmaBit(efer) ||
					!currentProcessor->guestVmcb.stateSaveArea.efer.cmpLmeBit(efer) ||
					!currentProcessor->guestVmcb.stateSaveArea.efer.cmpNxeBit(efer))
				{
					Vmexits::InvalidException(currentProcessor);
				}

				currentProcessor->guestVmcb.stateSaveArea.efer = efer;
			}

			__writemsr(msrRegister, value.QuadPart);
		}
		else
		{

			value.QuadPart = __readmsr(msrRegister);

			context->guestRegisters->rax = value.LowPart;
			context->guestRegisters->rdx = value.LowPart;
		}


end:
		currentProcessor->guestVmcb.stateSaveArea.rip = currentProcessor->guestVmcb.controlArea.nRip;
	}



	bool OutSideMsrMap(__inout const uint32_t& msr)
	{
		if ((msr > 0) && (msr < 0xc0011FFF)) return true;

		return false;
		
	}



	bool HypervMsr(__inout const uint32_t& msr)
	{
		if (((msr > 0) && (msr < 0x00001FFF)) || ((msr > 0xC0000000) && (msr < 0xC0001FFF)) || (msr > 0xC0010000) && (msr < 0xC0011FFF)) return true;

		return false;
	}



	void RdtscExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context)
	{
		
		auto time = __rdtsc();
		context->guestRegisters->rax = static_cast<uint32_t>(time);
		context->guestRegisters->rdx = static_cast<uint32_t>(time >> 32);

		currentProcessor->guestVmcb.stateSaveArea.rip = currentProcessor->guestVmcb.controlArea.nRip;
	}



	void XSetBvExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context)
	{
		
		_XCR0_REGISTER xcr0{};
		auto& cachedXcr0 = currentProcessor->hostStack.layout.xSetBvMask; 
		auto& cr4 = currentProcessor->guestVmcb.stateSaveArea.cr4;


		if (cr4.bit.osxsave == 1)
		{
			InvalidException(currentProcessor);
			goto end;
		}
			
		if (context->guestRegisters->rcx != 0)
		{
			GeneralException(currentProcessor);
			goto end;
		}
			

		xcr0 = ((context->guestRegisters->rdx & MAXUINT32) | (context->guestRegisters->rax & MAXUINT32));

		if (xcr0 != cachedXcr0)
		{
			GeneralException(currentProcessor);
			goto end;
		}
			
		if (!xcr0.CheckX87())
		{
			GeneralException(currentProcessor);
			goto end;
		}
			
		_xsetbv(static_cast<uint32_t>(context->guestRegisters->rcx.GetR64()), xcr0.GetValue());

		end:

		currentProcessor->guestVmcb.stateSaveArea.rip = currentProcessor->guestVmcb.controlArea.nRip;
	}


	void RdtscpExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context)
	{
		
		uint32_t rdtscpinput = 0;
		auto time = __rdtscp(&rdtscpinput);

		context->guestRegisters->rax = static_cast<uint32_t>(time);
		context->guestRegisters->rdx = static_cast<uint32_t>(time >> 32);
		context->guestRegisters->rcx = static_cast<uint32_t>(rdtscpinput);

		currentProcessor->guestVmcb.stateSaveArea.rip = currentProcessor->guestVmcb.controlArea.nRip;
	}


};