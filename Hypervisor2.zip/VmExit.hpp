#ifndef VMEXIT_HPP
#define VMEXIT_HPP


#include "hypervisor.hpp"


namespace Vmexits
{
	void CpuidExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context);

	void MsrExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context);

	bool HypervMsr(__inout const uint32_t& msr);

	bool OutSideMsrMap(__inout const uint32_t& msr);

	void RdtscExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context);

	void XSetBvExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context);

	void RdtscpExit(__inout _HV_CPU* currentProcessor, __inout _EXIT_CONTEXT* context);

	void InvalidException(__inout _HV_CPU* currentProcessor);

	void GeneralException(__inout _HV_CPU* currentProcessor);

	bool Cpl3(__inout _HV_CPU* currentProcessor);


	///// <summary>
	///// not implemented yet
	///// </summary>
	///// <param name="currentProcessor"></param>
	///// <param name="flushType"></param>
	//void FlushTlbEntries(__in _HV_CPU* currentProcessor, __in uint32_t flushType);

	//void CleanVmcb(__in _HV_CPU* currentProcessor, __in bool clean);



	EXTERN_C bool __stdcall HandleVmExit(__inout _HV_CPU* currentProcessor, __inout _GUEST_REGISTERS* guestRegisters)
	{
		_EXIT_CONTEXT context = { 0 };
		context.guestRegisters = guestRegisters;
		context.exit = false;

		
		__svm_vmload(currentProcessor->hostStack.layout.hostVmcbPa);

		auto irql = KeGetCurrentIrql();
		if (irql < HIGH_LEVEL)
		{
			KeRaiseIrql(HIGH_LEVEL, &irql);
		}

		guestRegisters->rax = currentProcessor->guestVmcb.stateSaveArea.rax;

		NT_VERIFY(currentProcessor->hostStack.layout.reserved0 == MAXINT64);
		
		switch (currentProcessor->guestVmcb.controlArea.exitCode)
		{
		case VMEXIT_VMRUN:
		case VMEXIT_VMLOAD:
		case VMEXIT_VMSAVE:
		case VMEXIT_CLGI:	
		case VMEXIT_SKINIT:		
		case VMEXIT_STGI:
			Vmexits::InvalidException(currentProcessor);
			break;
		case VMEXIT_CPUID:
			CpuidExit(currentProcessor, &context);
			break;
		case VMEXIT_RDTSC:
			RdtscExit(currentProcessor, &context);
			break;
		case VMEXIT_MSR:
			MsrExit(currentProcessor, &context);
			break;
		case VMEXIT_RDTSCP:
			RdtscpExit(currentProcessor, &context);
			break;
		case VMEXIT_XSETBV:
			XSetBvExit(currentProcessor, &context);
			break;
		default:
			DEBUG_BREAK();
			KeBugCheckEx(0xFA11UL, Vmexits::Cpl3(currentProcessor), currentProcessor->guestVmcb.stateSaveArea.rip, currentProcessor->guestVmcb.controlArea.exitCode, 0);
			break;
		}

		if (irql < HIGH_LEVEL)
		{
			KeLowerIrql(irql);
		}

		
		if (context.exit)
		{
			context.guestRegisters->rax = reinterpret_cast<uintmax_t>(currentProcessor) & MAXUINT32;
			context.guestRegisters->rbx = currentProcessor->guestVmcb.controlArea.nRip;
			context.guestRegisters->rcx = currentProcessor->guestVmcb.stateSaveArea.rsp;
			context.guestRegisters->rdx = reinterpret_cast<uintmax_t>(currentProcessor) >> 32;


			__svm_vmload(currentProcessor->hostStack.layout.guestVmcbPa);


			_disable();
			__svm_stgi();


			__writemsr(MSR_EFER, __readmsr(MSR_EFER) & ~EFER_SVME);
			__writeeflags(currentProcessor->guestVmcb.stateSaveArea.rflags.value);
			goto exit;
		}

		currentProcessor->guestVmcb.stateSaveArea.rax = context.guestRegisters->rax.GetR64();

		
	exit:
		NT_VERIFY(currentProcessor->hostStack.layout.reserved0 == MAXINT64);

		return context.exit;
	}


}; // namespace Vmexits

#endif // !VMEXIT_HXX


