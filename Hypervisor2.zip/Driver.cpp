﻿#include "Hypervisor.hpp"
#include "CustomFunctions.hpp"


#define POOL_NX_OPTIN   1
EXTERN_C DRIVER_INITIALIZE DriverEntry;

#ifdef HYPER_V

static DRIVER_UNLOAD UnloadDriver;

_Use_decl_annotations_
static 
void UnloadDriver(PDRIVER_OBJECT pDriverObject)
{
	auto unload = reinterpret_cast<Hypervisor*>(pDriverObject->DriverStart);

	unload->Devirtualize();
}

#endif // HYPER_V


_Use_decl_annotations_
EXTERN_C
NTSTATUS DriverEntry(__in PDRIVER_OBJECT  DriverObject, __in PUNICODE_STRING RegistryPath)
{
	UNREFERENCED_PARAMETER(RegistryPath);

	KPRINT("[+]DriverEntry Called\n");
	

	DriverObject->DriverUnload = UnloadDriver;

	ExInitializeDriverRuntime(DrvRtPoolNxOptIn);

	Inlines::GetModuleList(&Inlines::moduleList);
	if (Inlines::moduleList->count == 0)
	{
		KPRINT("[-]Failed To Get Module List\n");
		Inlines::poolFree(&Inlines::moduleList);
		return STATUS_UNSUCCESSFUL;
	}

	KPRINT("[+]Module List Success\n");

	Inlines::kernelBase = Inlines::FindModule(&Inlines::moduleList, &Inlines::szKernel, "ntoskrnl.exe");
	if (!Inlines::kernelBase)
	{
		KPRINT("[-]Failed To Find Kernel Base\n");
		Inlines::poolFree(&Inlines::moduleList);
		return STATUS_UNSUCCESSFUL;
	}

	KPRINT("[+]Found kernel Base Loacated At : 0x%I64X\n", Inlines::kernelBase);

	Inlines::miGetPteAddress = Inlines::signatureScanner((UCHAR*)Inlines::kernelBase, Inlines::szKernel, Inlines::_MIGETPTEADDRESS, sizeof(Inlines::_MIGETPTEADDRESS));
	if (!Inlines::miGetPteAddress)
	{
		KPRINT("[-]Failed To Find MiGetPteAddress\n");
		Inlines::poolFree(&Inlines::moduleList);
		return STATUS_UNSUCCESSFUL;
	}

	KPRINT("[+]Found MiGetPteAddress Located At : 0x%I64X\n", Inlines::miGetPteAddress);

	auto hypervisor = reinterpret_cast<Hypervisor*>(Inlines::contigAlloc(sizeof(Hypervisor)));
	if (!hypervisor)
	{
		KPRINT("[-]Failed to allocate hypervisor\n");
		Inlines::poolFree(&Inlines::moduleList);
		return STATUS_UNSUCCESSFUL;
	}

	DriverObject->DriverStart = reinterpret_cast<void*>(hypervisor);

	if (!hypervisor->HypervisorInit())
	{
		KPRINT("[-]Failed to initialize hypervisor\n");
		Inlines::poolFree(&Inlines::moduleList);
		Inlines::contigFree(hypervisor, sizeof(Hypervisor));
		return STATUS_UNSUCCESSFUL;
	}

	return STATUS_SUCCESS;
}

