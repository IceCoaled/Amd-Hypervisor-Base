﻿#include <ntifs.h>

#include "Hypervisor.hpp"
#include "CustomFunctions.hpp"



    void Hypervisor::BuildOutVmcb(__inout _HV_CPU* currentProcessor, __inout const _GUEST_CONTEXT* context)
    {

        auto* control = &currentProcessor->guestVmcb.controlArea;
        auto* state = &currentProcessor->guestVmcb.stateSaveArea;
        auto* cs = &state->cs;
        auto* ds = &state->ds;
        auto* es = &state->es;
        auto* ss = &state->ss;
        

        const auto hostStateAreaPa = MmGetPhysicalAddress(&currentProcessor->hostStateArea).QuadPart;
        const auto sharedPagesPa = MmGetPhysicalAddress(&Hypervisor::nestedTables->pml4e).QuadPart;
        const auto guestPa = MmGetPhysicalAddress(&currentProcessor->guestVmcb).QuadPart;
        const auto hostPa = MmGetPhysicalAddress(&currentProcessor->hostVmcb).QuadPart;
        const auto msrPa = MmGetPhysicalAddress(Hypervisor::nestedTables->msrMap).QuadPart;
        
    

        control->vector4.bit.vmRun = 1;
        control->vector4.bit.vmLoad = 1;
        control->vector4.bit.vmSave = 1;
        control->vector4.bit.vmCall = 1;
        control->vector4.bit.xsetbv = 1;
        control->vector4.bit.rdtscp = 1;
        control->vector4.bit.clgi = 1;
        control->vector4.bit.skinit = 1;
        control->vector4.bit.stgi = 1;
        control->vector3.bit.msrProto = 1;
        control->vector3.bit.cpuid = 1;
        control->vector3.bit.rdtsc = 1;

        
       
        control->guestAsid.value = 1;
        control->npEnable.value |= SVM_NP_ENABLE;
        control->nCr3 = sharedPagesPa;
        control->msrpmBasePa = msrPa;

        state->gdtr.base = context->gdtr.base;
        state->gdtr.limit = context->gdtr.limit;
        state->idtr.base = context->idtr.base;
        state->idtr.limit = context->idtr.limit;

        cs->selector.value = context->cs;
        ds->selector.value = context->ds;
        es->selector.value = context->es;
        ss->selector.value = context->ss;

        cs->limit = static_cast<uint32_t>(__segmentlimit(context->cs));
        ds->limit = static_cast<uint32_t>(__segmentlimit(context->ds));
        es->limit = static_cast<uint32_t>(__segmentlimit(context->es));
        ss->limit = static_cast<uint32_t>(__segmentlimit(context->ss));

     
        cs->FetchAtts(context->gdtr.base);
        ds->FetchAtts(context->gdtr.base);
        es->FetchAtts(context->gdtr.base);
        ss->FetchAtts(context->gdtr.base);

        state->efer = context->efer;
        state->cr0.value = context->cr0;
        state->cr2 = context->cr2;
        state->cr3.value = context->cr3;
        state->cr4.value = context->cr4;
        state->rflags.value = context->rflags;
        state->rsp = context->rsp;
        state->rip = context->rip;
        state->gPat = context->gPat;


        __svm_vmsave(guestPa);


        currentProcessor->hostStack.layout.reserved0 = MAXUINT64;
        currentProcessor->hostStack.layout.xSetBvMask = Hypervisor::xCr0BitMask;
        currentProcessor->hostStack.layout.nestedPages = Hypervisor::nestedTables;
        currentProcessor->hostStack.layout.hvProcessor = currentProcessor;
        currentProcessor->hostStack.layout.hostVmcbPa = hostPa;
        currentProcessor->hostStack.layout.guestVmcbPa = guestPa;

        __writemsr(SVM_MSR_VM_HSAVE_PA, hostStateAreaPa);
  
        __svm_vmsave(hostPa);
    }



    NTSTATUS Hypervisor::VirtualizeProcessor()
    {    
    
        _GUEST_CONTEXT state = { 0 };
        NTSTATUS status = -1;

#ifndef HYPER_V

        auto* currentProcessor = &Hypervisor::processors[KeGetCurrentProcessorNumberEx(nullptr)];
#else
        
        auto* currentProcessor = static_cast<_HV_CPU*>(Inlines::poolAlloc(sizeof(_HV_CPU)));
		if (!currentProcessor)
			return STATUS_NO_MEMORY;

#endif // !HYPER_V

      
       _MSR_VM_CR vmCr{};
       vmCr.ReadValue();
       if (vmCr.svmeDisable())
       {
           vmCr.LockAndWrite();
       }

        
        _EFER_REGISTER efer{};
        efer.ReadValue();
        if (!efer.bit.svme)
        {
            efer.SetSvmeBit();
            efer.WriteValue();
        }
       
        
        CAPTURE_GUEST(&state);

#ifdef HYPER_V

        if (!Hypervisor::HyperVirtulizationCheck())
        {
            Hypervisor::BuildOutVmcb(currentProcessor, &state);

            LaunchVm(&currentProcessor->hostStack.layout.guestVmcbPa);

            DEBUG_BREAK();
            KeBugCheck(MANUALLY_INITIATED_CRASH);
        }

#else
        
        if (!Hypervisor::VirtulizationCheck())
        {
            Hypervisor::BuildOutVmcb(currentProcessor, &state);

            LaunchVm(&currentProcessor->hostStack.layout.guestVmcbPa);

            DEBUG_BREAK();
            KeBugCheck(MANUALLY_INITIATED_CRASH);
        }

#endif // 

      

        KPRINT("[+]Processor Virtualized\n");
      
        return STATUS_SUCCESS;
    }



    template<typename lmda>
    NTSTATUS Hypervisor::RunProcessors(lmda&& callback)
    {
        ULONG i = 0;
        NTSTATUS status = STATUS_UNSUCCESSFUL;
        PROCESSOR_NUMBER procNumber = { 0 };
        GROUP_AFFINITY affinity = { 0 };
        GROUP_AFFINITY dwAffinity = { 0 };
        ULONG processorCount = KeQueryActiveProcessorCountEx(ALL_PROCESSOR_GROUPS);



        for (; i < processorCount; i++)
        {   
            
            if (!NT_SUCCESS(status = KeGetProcessorNumberFromIndex(i, &procNumber)))
            {
			    break;
            }
				
            affinity.Group = procNumber.Group;
            affinity.Mask = 1ULL << procNumber.Number;
            affinity.Reserved[0] = affinity.Reserved[1] = affinity.Reserved[2] = 0;

            KeSetSystemGroupAffinityThread(&affinity, &dwAffinity);
 
            status = callback();

            KeRevertToUserGroupAffinityThread(&dwAffinity);

            if (!NT_SUCCESS(status))
                break;
        }

        if (!NT_SUCCESS(status) || i != processorCount)
		{
			return status;
		}


        return STATUS_SUCCESS;
    }



    NTSTATUS Hypervisor::StartVm()
    {
        NTSTATUS status = STATUS_UNSATISFIED_DEPENDENCIES;
       
        auto VpCallback = [this]() -> NTSTATUS
        {
            return Hypervisor::VirtualizeProcessor();
        };
   	     
#ifndef HYPER_V

        Hypervisor::processors = static_cast<_HV_CPU*>(Inlines::poolAlloc(sizeof(_HV_CPU) * KeQueryActiveProcessorCountEx(ALL_PROCESSOR_GROUPS)));
        if (!Hypervisor::processors)
            return STATUS_NO_MEMORY;

#endif // !HYPER_V

      
        
        KPRINT("[+]Nested Pages Setup\n");
        Hypervisor::nestedTables = static_cast<_SHARED_PAGES*>(Inlines::poolAlloc(sizeof(_SHARED_PAGES)));
        if (!Hypervisor::nestedTables)
            goto end;
       
         
        Hypervisor::SetupTables(Hypervisor::nestedTables);
        KPRINT("[+]Nested Pages Setup Success\n");

       
        
        KPRINT("[+]MSR Map Setup\n");     
        Hypervisor::nestedTables->msrMap = Inlines::contigAlloc(SVM_MSR_PERMISSIONS_MAP_SIZE);
        if (!Hypervisor::nestedTables->msrMap)
            goto end;

       
        MsrSetup(Hypervisor::nestedTables->msrMap);
        KPRINT("[+]MSR Map Setup Success\n");

        
        KPRINT("[+]Fetching Xcr0 Register Bit Mask\n");

        DEBUG_BREAK();
        Hypervisor::xCr0BitMask.ReadValue();

        
        status = Hypervisor::RunProcessors(VpCallback);
        
        if (!NT_SUCCESS(status))
           goto end;

        KPRINT("[+]Hypervisor Started\n");

        return STATUS_SUCCESS;

    end:

        if (Hypervisor::processors)Inlines::poolFree(Hypervisor::processors);
        if (Hypervisor::nestedTables)Inlines::poolFree(Hypervisor::nestedTables);
        if (Hypervisor::nestedTables->msrMap)Inlines::contigFree(Hypervisor::nestedTables->msrMap, SVM_MSR_PERMISSIONS_MAP_SIZE);

		return status;
    }



    void Hypervisor::SetupTables(__inout _SHARED_PAGES* sharedPages) const
    {
   	  auto* pages = sharedPages;
        
        const auto pdpBasePa = MmGetPhysicalAddress(&pages->pdpe).QuadPart;
        pages->pml4e[0].bit.pageFrameNumber = pdpBasePa >> PAGE_SHIFT;
        pages->pml4e[0].bit.valid = 1;
        pages->pml4e[0].bit.write = 1;
        pages->pml4e[0].bit.user = 1;

        for (uintmax_t pdpIndex = 0; pdpIndex < TABLE_PAGE_SIZE; pdpIndex++)
        {
  
            const auto pdeBasePa = MmGetPhysicalAddress(&pages->pde[pdpIndex][0]).QuadPart;
            pages->pdpe[pdpIndex].bit.pageFrameNumber = pdeBasePa >> PAGE_SHIFT;
            pages->pdpe[pdpIndex].bit.valid = 1;
            pages->pdpe[pdpIndex].bit.write = 1;
            pages->pdpe[pdpIndex].bit.user = 1;

            for (uintmax_t pdIndex = 0; pdIndex < TABLE_PAGE_SIZE; pdIndex++)
            {
                const auto transAddr = (pdpIndex << 9) ^ pdIndex;
                pages->pde[pdpIndex][pdIndex].bit.pageFrameNumber = transAddr;
                pages->pde[pdpIndex][pdIndex].bit.valid = 1;
                pages->pde[pdpIndex][pdIndex].bit.write = 1;
                pages->pde[pdpIndex][pdIndex].bit.user = 1;
                pages->pde[pdpIndex][pdIndex].bit.largePage = 1;
            }
        }
    }


    void Hypervisor::CheckForSetupFlags()
    {
       int32_t registers[4] = { -1 };
       _CR0_REGISTER cr0{};
       cr0.value = __readcr0();
       _CR4_REGISTER cr4{};
       cr4.value = __readcr4();
       _RFLAGS_REGISTER rFlags{};
       rFlags.value = __getcallerseflags();

       
       
        // eax ebx ecx edx
        __cpuid(registers, CPUID_PROCESSOR_AND_PROCESSOR_FEATURE_IDENTIFIERS);
        if ((registers[2] & CPUID_FN0000_0001_ECX_X2APIC_MODE))
        {
            Hypervisor::setupFlags.value |= X2APIC_ENABLED;
            KPRINT("[+]X2APIC Mode Enabled\n");
        }
    
        
        if (cr4.bit.pcide)
        {
            Hypervisor::setupFlags.value |= PCIDE_ENABLED;
            KPRINT("[+]PCIDE Enabled\n");
        }

        if (cr4.bit.la57)
        {
            Hypervisor::setupFlags.value |= LEVEL5_PAGING;
            KPRINT("[+]Level 5 Paging Enabled\n");
        }


        if (rFlags.bit.virtual8086)
        {  
            KPRINT("[+Virtual 8086 Mode enabled\n");
            return;
        }

        if (cr0.bit.pg && cr0.bit.pe)
		{
			Hypervisor::setupFlags.value |= SHADOW_STACK_OPERATIONAL;
            KPRINT("[+]Shadow Stack Operational\n");
		}
         
    }


    NTSTATUS Hypervisor::CheckSupport()
    {
        int32_t registers[4] = { -1 };


        // eax ebx ecx edx
        __cpuid(registers, CPUID_MAX_STANDARD_FN_NUMBER_AND_VENDOR_STRING);
        if ((registers[1] != 'htuA') ||
            (registers[3] != 'itne') ||
            (registers[2] != 'DMAc'))
            return STATUS_HV_INVALID_DEVICE_ID;


        __cpuid(registers, CPUID_PROCESSOR_AND_PROCESSOR_FEATURE_IDENTIFIERS_EX);
        if (!(registers[2] & CPUID_FN8000_0001_ECX_SVM))
            return STATUS_HV_CPUID_FEATURE_VALIDATION_ERROR;


        if (!(registers[3] & CPUID_FN8000_0001_EDX_LONG_MODE))
            return STATUS_HV_CPUID_FEATURE_VALIDATION_ERROR;


        __cpuid(registers, CPUID_SVM_FEATURES);
        if (!(registers[3] & CPUID_FN8000_000A_EDX_NP))
            return STATUS_HV_CPUID_FEATURE_VALIDATION_ERROR;


        const auto vmcr = __readmsr(SVM_MSR_VM_CR);
        if (vmcr & SVM_VM_CR_SVMDIS)
            return STATUS_HV_INVALID_DEVICE_STATE;


        KPRINT("[+]Support Success\n");

        return STATUS_SUCCESS;
    }


    void Hypervisor::MsrSetup(__inout void* msrPermsAddr)
    {

        RTL_BITMAP msrBitmap = { 0 };
        constexpr uint16_t bitsPerMsr = 0x02;
        constexpr uintmax_t msrRange = 0xC0000000;
        constexpr uint16_t szVector = (0x800 * CHAR_BIT);
        constexpr uintmax_t registerOffset = (MSR_EFER - msrRange) * bitsPerMsr;
        constexpr uintmax_t offset = registerOffset + szVector;

        RtlInitializeBitMap(&msrBitmap, static_cast<PULONG>(msrPermsAddr), (SVM_MSR_PERMISSIONS_MAP_SIZE * CHAR_BIT));
        RtlClearAllBits(&msrBitmap);
        RtlSetBits(&msrBitmap, (offset + 0x01UL), 0x01UL);
    }



    __declspec(noinline) bool Hypervisor::HyperVirtulizationCheck()
    {
     
        int32_t registers[4] = { -1 };
        char vendor[13] = { 0 };
        vendor[12] = '\0';
       


        __cpuid(registers, CPUID_HV_VENDOR_AND_MAX_FUNCTIONS);

        Inlines::memCpy(vendor + 0, &registers[1], sizeof(registers[1]));
        Inlines::memCpy(vendor + 4, &registers[2], sizeof(registers[2]));
        Inlines::memCpy(vendor + 8, &registers[3], sizeof(registers[3]));

        
        if (strcmp(vendor, "IceCoaled   ") != 0) return false;
       
        return true;
    }



    __declspec(noinline) bool Hypervisor::VirtulizationCheck()
    {
        const auto processorIndex = KeGetCurrentProcessorNumberEx(nullptr);

        if (!Hypervisor::ProcessorVirtualized[processorIndex])
        {
            Hypervisor::ProcessorVirtualized[processorIndex] = true;

            return false;
        }

        return true;
    }


#ifdef HYPER_V
    
    NTSTATUS Hypervisor::DevirtualizeProcessor()
    {
        //eax ebx ecx edx
        int32_t registers[4];   
        uintmax_t high = 0;
        uintmax_t low = 0;
        _HV_CPU* currentProcessor = nullptr;

        __cpuidex(registers, CPUID_UNLOAD, CPUID_UNLOAD);
        if (registers[2] != 'Ice')
        {
            goto exit;
        }

       KPRINT("The processor has been Devirtualized\n");

        high = registers[3];
        low = registers[0] & MAXUINT32;
        currentProcessor = reinterpret_cast<_HV_CPU*>(high << 32 | low);
        NT_ASSERT(vpData->HostStackLayout.Reserved1 == MAXUINT64);

        Inlines::poolFree(currentProcessor);

    exit:
        return STATUS_SUCCESS;
    }


    void Hypervisor::Devirtualize()
	{
		auto DpCallback = [this]() -> NTSTATUS
		{
			return Hypervisor::DevirtualizeProcessor();
		};

		NT_VERIFY(NT_SUCCESS(Hypervisor::RunProcessors(DpCallback)));

        if (Hypervisor::nestedTables->msrMap)Inlines::contigFree(Hypervisor::nestedTables->msrMap, SVM_MSR_PERMISSIONS_MAP_SIZE);
        if (Hypervisor::nestedTables)Inlines::poolFree(Hypervisor::nestedTables);
	}

#endif // HYPER_V