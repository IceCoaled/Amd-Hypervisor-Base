﻿#ifndef HYPERVISOR_HPP
#define HYPERVISOR_HPP

#include <intrin.h>
#include "Cpu.hpp"
#include "Svm.hpp"


#define HYPER_V



#ifdef HYPER_V

#define KPRINT(fmt, ...) \
    if (KD_DEBUGGER_NOT_PRESENT) \
    { \
        NOTHING; \
    } \
    else \
    { \
        DbgPrint(fmt, __VA_ARGS__); \
    } \
    reinterpret_cast<void*>(0)

#define DEBUG_BREAK() \
    if (KD_DEBUGGER_NOT_PRESENT) \
    { \
        NOTHING; \
    } \
    else \
    { \
        __debugbreak(); \
    } \
    reinterpret_cast<void*>(0)


#endif // HYPER_V





class Hypervisor
{

private:
	_HV_CPU* processors = nullptr;
	_SHARED_PAGES* nestedTables = nullptr;
	bool ProcessorVirtualized[64] = { false };

private:
	_SETUP_FLAGS setupFlags{};
	_XCR0_REGISTER xCr0BitMask{};
private:


	void CheckForSetupFlags();
	
	void SetupTables(__inout _SHARED_PAGES* sharedPages) const;
	
	template<typename lmda>
	NTSTATUS RunProcessors(lmda&& callback);

	NTSTATUS CheckSupport();
	
	void MsrSetup(__inout void* msrPermsAddr);
	
	bool HyperVirtulizationCheck();
	
	void BuildOutVmcb(__inout _HV_CPU* currentProcessor, __inout const _GUEST_CONTEXT* context);
	
	NTSTATUS VirtualizeProcessor();

	bool VirtulizationCheck();
	
	NTSTATUS StartVm();
	
public:
	
	NTSTATUS HypervisorInit()
	{

		if (Hypervisor::CheckSupport() != STATUS_SUCCESS)
		{
			
			KPRINT("[-]HypervisorInit Failed\n");
			return STATUS_UNSATISFIED_DEPENDENCIES;
		}

		Hypervisor::CheckForSetupFlags();

		KPRINT("[+]HypervisorInit Success\n");


		return Hypervisor::StartVm();
	}

#ifdef HYPER_V

	void Devirtualize(void);

private:
	NTSTATUS DevirtualizeProcessor(void);

#endif // HYPER_V
};




EXTERN_C_START

void _sgdt(__out void* descriptor);

__declspec(noreturn) void __stdcall LaunchVm(void* guestVmcbPhysicalAddr);


uint16_t __stdcall ReadCs();
uint16_t __stdcall ReadSs();
uint16_t __stdcall ReadEs();
uint16_t __stdcall ReadDs();
uintmax_t __stdcall ReadEFlags();
uintmax_t __stdcall ReadRsp();
uintmax_t __stdcall ReadRip();
 

 EXTERN_C_END


#define CAPTURE_GUEST(state)\
	Inlines::memSet(state, 0, sizeof(_GUEST_CONTEXT));\
	_sgdt(&(state)->gdtr);\
	__sidt(&(state)->idtr);\
	(state)->cs = ReadCs();\
	(state)->ss = ReadSs();\
	(state)->ds = ReadDs();\
	(state)->es = ReadEs();\
	(state)->cr0 = __readcr0();\
	(state)->cr2 = __readcr2();\
	(state)->cr3 = __readcr3();\
	(state)->cr4 = __readcr4();\
	(state)->efer = __readmsr(MSR_EFER);\
    (state)->gPat = __readmsr(MSR_PAT);\
	(state)->rflags = ReadEFlags();\
	(state)->rsp = ReadRsp();\
    (state)->rip = ReadRip();

#endif // !HYPERVISOR_HXX

